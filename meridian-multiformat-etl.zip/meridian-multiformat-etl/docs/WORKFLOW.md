# Workflow and Key Concepts

## 1. End-to-end flow

```
                ┌──────────────────────── raw/ (Volume) ───────────────────────┐
                │  pos_*.csv     ecommerce_*.json    product_*.xml    *.xlsx   │
                └──────┬──────────────┬──────────────────┬──────────────┬──────┘
 01_extract     glob("*.csv")   glob("*.json")     glob("*.xml")   glob("*.xlsx")
                       │              │                  │              │
                 extract_csv    extract_json       extract_xml    extract_excel
                       │       (json_normalize)    (ElementTree)  (2 sheets)
                       ▼              ▼                  ▼              ▼
 bronze/        store_sales     web_orders          products      locations, fx_rates
                └──────────── raw dict → .astype("string") → Parquet ───────────┘
                                         │
 02_transform   transform(): clean_locations → clean_fx_rates → clean_products
                             → clean_store_sales(uses locations) → clean_web_orders
                                         ▼
 silver/        5 clean tables with real types (numbers, dates) → Parquet
                                         │
 03_load        build_gold():
                  standardize_store_sales + standardize_web_orders  (same 10 columns)
                  → combine (concat)                                9,201 rows
                  → enrich  (left joins: locations, products, fx on date+currency)
                  → calculate (revenue_usd, cost_usd, profit_usd)
                                         ▼
 processed/     sales_consolidated.csv  (Gold)
                                         │
 04_analysis    profit_summary("channel" | "country" | "category")

 Every step → log_progress() → logs/etl_log.txt
 Databricks Job runs: extract → transform → load → analysis
```

## 2. Where the data lives at each step

| Stage | Location | Format | Why this format |
|---|---|---|---|
| Raw | `raw/` | as delivered | Never modified, the source of truth. Any run can restart from here. |
| Bronze | `bronze/` | Parquet, all text | Extracted but **unchanged**. Text keeps dirty values like `"94,99"` intact. |
| Silver | `silver/` | Parquet, typed | Cleaned. Parquet keeps the types (dates, numbers) that CSV would lose. |
| Gold | `processed/` | CSV | Final table, easy for analysts or BI tools to open |
| In memory | notebook session | DataFrames | `raw`, `bronze`, `silver` and `gold` disappear when the session ends |

## 3. How each format is handled (01_extract)

| Format | Challenge | Solution |
|---|---|---|
| CSV | Already flat | `pd.read_csv(path, dtype=str)` |
| JSON lines | One order per line; `items` is a **nested list** | `json.loads` per line, then `pd.json_normalize(record_path="items", meta=[...])` gives one row per item, with order fields repeated |
| XML | Tree of tags and attributes | `ET.parse().getroot()`, loop over `<product>`, `p.get("id")` for attributes, `p.findtext("pricing/list_price")` for nested tags |
| Excel | Two sheets in one file | `pd.read_excel(sheet_name=None)` returns `{sheet: DataFrame}`, saved as 2 Bronze tables |

**Type detection:** each `glob(f"{RAW_DIR}/*.csv")` loop only matches its extension, so the pattern itself decides which extractor runs.

## 4. What cleaning fixes (02_transform)

| Function | Problems found → fix |
|---|---|
| `clean_store_sales` | `" ST-AUS"` / `"st-aus"` → strip + upper (**before** dedup), POS duplicates → `drop_duplicates`, `"94,99"` → `94.99`, Berlin dates `01.07.2026` → second `to_datetime` format via `fillna`, missing currency → store's currency from `locations`, no price → dropped and logged |
| `clean_web_orders` | `TEST` orders removed, refunded orders appear twice (placed + updated) → `drop_duplicates(keep="last")` keeps the latest status, `qty` as text → `to_numeric`, epoch-millisecond timestamps → `unit="ms"`, missing currency → from customer country |
| `clean_products` | `" OUTDOOR "` → `.str.strip().str.title()`, `"$12.30"` → strip `$`, duplicate product records → keep last |
| `clean_locations` | Text → numbers and dates |
| `clean_fx_rates` | `"1,0912"` → `1.0912`, text dates, lowercase codes, **no weekend rates** → pivot by day, `reindex` every date, `ffill` (carry Friday's rate forward), melt back |

## 5. How the final file is built (03_load)

1. **Standardize.** Both sales sources are renamed to the same columns (`qty` becomes `quantity`, `storefront` becomes `location_id`, and so on). `concat` only aligns columns with identical names.
2. **Combine.** `pd.concat` stacks store and web sales.
3. **Enrich.** Three `merge(how="left")` joins. A **left** join keeps every sale even when no match is found, so unknown products show as `"Unknown product"` instead of disappearing.
   - `locations` on `location_id` → channel, region (and the store's country)
   - `products` on `product_id` → name, category, unit cost
   - `fx_rates` on **`sale_date` + `currency`** → that day's rate
4. **Calculate.**
   - `revenue_usd = quantity × unit_price_local × (1 − discount_rate) × fx_rate`
   - `cost_usd = quantity × unit_cost`, `profit_usd = revenue − cost`
   - Refunded and cancelled orders earn `0`. Returns have negative quantity, so they reduce revenue.

## 6. Key concepts to remember

- **ETL:** Extract (read the sources), Transform (clean and reshape), Load (write the result).
- **Medallion architecture:** Bronze (raw) → Silver (clean) → Gold (business-ready). Each layer is saved, so you can debug or re-run from any stage.
- **Keep sources separate until they share a shape.** The course version concatenated everything right away, which only works when all files have the same columns.
- **Dictionaries of DataFrames.** `raw["store_sales"]` is a key → DataFrame lookup, and the whole pipeline passes these dicts between steps.
- **`errors="coerce"`:** unconvertible values become `NaN` instead of crashing, so they can be counted and handled.
- **Logging:** a timestamped, append-only trail written to a file and printed to the Job output.
- **Orchestration:** the Databricks Job encodes the order and dependencies (`extract → transform → load`) and runs it on a schedule.

## 7. Design choices and limitations

| Choice | Why | Limitation |
|---|---|---|
| One `glob` loop per type | Easy to read, and the pattern is the detection | `raw["store_sales"] = ...` **overwrites**: with 2 CSV files, only the last is kept. Fix: collect a list and `concat`. |
| Paths and `log_progress` repeated in each notebook | Each notebook runs on its own in a Job | Changing a path means editing 4 notebooks |
| pandas, not Spark | Fits this data size, simpler to learn | Won't scale to very large data. PySpark would be the upgrade. |
| Full reload each run | Simple and reproducible | No incremental loading of only new files |
| Gold as CSV | Opens anywhere | No types or versioning. A Delta table would be better in production. |
