# Troubleshooting and Validation

## Errors we hit and how we fixed them

| Symptom | Cause | Fix |
|---|---|---|
| `PermissionError: [Errno 13] Permission denied: '/volumes'` on `os.makedirs` | The path started with lowercase `/volumes`. Paths are case-sensitive, so Python tried to create a new top-level folder. | Use **`/Volumes/...`** (capital V), copied from Catalog Explorer. Re-run the paths cell before retrying. |
| `NameError: name 'raw' is not defined` (or `log_progress`, `VOLUME_DIR`) in `02_transform` / `03_load` | **Notebooks don't share memory.** Variables from one notebook don't exist in another. | Each notebook re-defines its paths and `log_progress`, and reads the previous stage from `bronze/` or `silver/` |
| `Could not convert '3' with type str: tried to convert to int64 ... Conversion failed for column qty` when saving Bronze | The JSON `qty` field mixes numbers (`2`) and text (`"3"`). Parquet requires one type per column. | `df.astype("string").to_parquet(...)` saves Bronze as all text, then `02_transform` converts the types |
| Files not found / empty `raw` dict | Files were uploaded to the volume root, not `raw/` | Upload into `raw/`, or run the `shutil.move` snippet in REPRODUCE step 1 |
| Variables gone after a break | The notebook session restarted (idle timeout) | Re-run the cells. Data on the Volume is safe, and each notebook reloads its input from disk. |
| `ImportError: openpyxl` | Excel reader not installed | `%pip install openpyxl` as the first cell of `01_extract` |
| Weekend sales would have no FX rate | Finance publishes rates on weekdays only | `clean_fx_rates` fills every calendar day with the last known rate (`ffill`) |

## Validation checks

**After `01_extract`:** the shape check cell should print
```
store_sales: (4945, 13)
web_orders: (4796, 11)
products: (203, 5)
finance/locations: (7, 12)
finance/fx_rates: (264, 4)
```

**After `02_transform`:** the log should show
```
products: removed 3 duplicate product records
store_sales: dropped 30 rows with no price
Cleaned locations: 7 -> 7 rows
Cleaned fx_rates: 264 -> 368 rows
Cleaned products: 203 -> 200 rows
Cleaned store_sales: 4945 -> 4844 rows
Cleaned web_orders: 4796 -> 4357 rows
```

**After `03_load`:**
```
Combined: 4844 store + 4357 web = 9201 sales
Enrich: 27 sales with a product_id not in the catalog
Saved 9201 rows to .../processed/sales_consolidated.csv
```

**Quick data checks on Gold:**
```python
gold.isna().sum()[lambda s: s > 0]         # only cost_usd / profit_usd: 132 rows (unknown products or missing cost)
gold["status"].value_counts()              # completed 8538, refunded 333, cancelled 238, returned 92
gold.groupby("channel")["revenue_usd"].sum().round(0)   # store ≈ 773,349 | web ≈ 669,906
```

**Log file:** each full run appends 32 lines, from `ETL Job Started` (01) to `ETL Job Ended` (03). The log is append-only, so repeated runs add more blocks.

## Known data notes (intentional)
- **27 sales** reference product IDs not in the catalog (`P9999`, `P0000`, `UNKNOWN`). They're kept as `"Unknown product"` with revenue but no cost.
- **2 products** have no unit cost, so their sales have no profit value.
- These would be reported back to the Merchandising team in a real setup.
