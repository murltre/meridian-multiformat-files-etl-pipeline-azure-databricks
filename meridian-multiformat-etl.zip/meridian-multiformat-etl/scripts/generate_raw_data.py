"""
Meridian Goods - raw data generator (Q3 2026).

Produces one export per team into data/raw/, with deliberate real-world messiness.
  - pos_store_sales_2026Q3.csv     Store Operations (POS terminals)
  - ecommerce_orders_2026Q3.json   E-commerce (order events, JSON lines)
  - product_catalog.xml            Merchandising (product management system)
  - finance_reference.xlsx         Finance (locations + daily FX rates)
"""

import csv
import json
import math
import random
import xml.etree.ElementTree as ET
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

import pandas as pd

random.seed(2026)
OUT = Path("data/raw")
START, END = date(2026, 7, 1), date(2026, 9, 30)
DAYS = [START + timedelta(d) for d in range((END - START).days + 1)]

def chance(p):
    return random.random() < p

# ---------------------------------------------------------------- reference

BASE_FX = {"USD": 1.00, "CAD": 0.73, "EUR": 1.09, "GBP": 1.27}  # 1 unit -> USD

LOCATIONS = [
    # id, name, channel, city, country, region, currency, manager, opened, sqm, rent, status
    ("ST-AUS", "Meridian Austin Flagship", "store", "Austin", "US", "North America", "USD", "Dana Whitfield", "2019-04-12", 820, 38500, "active"),
    ("ST-TOR", "Meridian Toronto Queen St", "store", "Toronto", "CA", "North America", "CAD", "Marc Tremblay", "2021-09-01", 610, 41200, "active"),
    ("ST-BER", "Meridian Berlin Mitte", "store", "Berlin", "DE", "Europe", "EUR", "Lena Hoffmann", "2022-03-15", 540, 29800, "active"),
    ("ST-LON", "Meridian London Soho", "store", "London", "GB", "Europe", "GBP", "Oliver Grant", "2023-06-20", 480, 46500, "active"),
    ("ST-PAR", "Meridian Paris Marais", "store", "Paris", "FR", "Europe", "EUR", "Claire Dubois", "2022-10-03", 390, 33900, "closed"),
    ("WEB-NA", "Meridian Online North America", "web", "Online", "US", "North America", "USD", "Priya Raman", "2020-01-15", None, None, "active"),
    ("WEB-EU", "Meridian Online Europe", "web", "Online", "DE", "Europe", "EUR", "Jonas Berg", "2022-05-02", None, None, "active"),
]

CATEGORIES = {
    "Electronics": (["Wireless", "Smart", "Portable", "Noise-Cancelling", "Compact", "Pro"],
                    ["Earbuds", "Speaker", "Charger", "Headphones", "Power Bank", "Smartwatch", "Webcam", "Keyboard"], (15, 250)),
    "Apparel": (["Merino", "Waterproof", "Lightweight", "Classic", "Thermal", "Trail"],
                ["Running Shoes", "Rain Jacket", "Hoodie", "Socks 3-Pack", "T-Shirt", "Fleece", "Beanie", "Leggings"], (12, 180)),
    "Home": (["Ceramic", "Cast Iron", "Bamboo", "Glass", "Stainless", "Linen"],
             ["French Press", "Mug", "Skillet", "Cutting Board", "Carafe", "Throw Blanket", "Candle", "Pan Set"], (10, 150)),
    "Sports": (["Adjustable", "Insulated", "Foldable", "Pro", "Eco", "Grip"],
               ["Yoga Mat", "Dumbbells", "Water Bottle", "Resistance Bands", "Jump Rope", "Foam Roller", "Gym Bag"], (8, 220)),
    "Outdoor": (["Ultralight", "Rugged", "Packable", "All-Season", "Solar"],
                ["Tent", "Headlamp", "Backpack", "Camp Chair", "Sleeping Bag", "Lantern"], (20, 300)),
    "Beauty": (["Organic", "Hydrating", "Daily", "Travel", "Gentle"],
               ["Face Cream", "Shampoo", "Lip Balm", "Sunscreen", "Body Wash"], (6, 60)),
}
BRANDS = {
    "Electronics": ["Voltline", "Meridian Basics", "Auralis"],
    "Apparel": ["Northpeak", "Meridian Basics", "Strata"],
    "Home": ["Hearthline", "Meridian Basics", "Kiln & Co"],
    "Sports": ["Kinetix", "Meridian Basics", "Corepace"],
    "Outdoor": ["Terra Trail", "Northpeak"],
    "Beauty": ["Glowroot", "Meridian Basics"],
}
SUPPLIERS = {
    "Electronics": [("SUP-101", "Shenzhen Audio Works", "CN"), ("SUP-102", "Taipei Circuit Ltd", "TW")],
    "Apparel": [("SUP-201", "Northline Apparel GmbH", "DE"), ("SUP-202", "Dhaka Textile Group", "BD")],
    "Home": [("SUP-301", "Hearth & Home Co.", "GB"), ("SUP-302", "Porto Ceramics SA", "PT")],
    "Sports": [("SUP-401", "PeakFit Sports Inc.", "CA")],
    "Outdoor": [("SUP-501", "Summit Gear Mfg", "US")],
    "Beauty": [("SUP-601", "Botanica Labs", "FR")],
}
COLORS = ["Black", "White", "Navy", "Olive", "Grey", "Sand", "Red"]
SIZES = ["XS", "S", "M", "L", "XL"]


def charm(x):
    """Round to a retail .99 price."""
    return max(math.floor(x) + 0.99, 1.99)

# ---------------------------------------------------------------- products (XML)

def build_products(n=200):
    products, seen = [], set()
    pid = 1000
    while len(products) < n:
        cat = random.choice(list(CATEGORIES))
        adjs, nouns, (lo, hi) = CATEGORIES[cat]
        name = f"{random.choice(adjs)} {random.choice(nouns)}"
        if name in seen:
            continue
        seen.add(name)
        price = charm(random.uniform(lo, hi))
        products.append({
            "product_id": f"P{pid}",
            "name": name,
            "category": cat,
            "brand": random.choice(BRANDS[cat]),
            "supplier": random.choice(SUPPLIERS[cat]),
            "list_price_usd": price,
            "unit_cost_usd": round(price * random.uniform(0.35, 0.62), 2),
            "launch_date": date(2023, 1, 1) + timedelta(random.randint(0, 1200)),
            "status": "discontinued" if chance(0.08) else "active",
            "weight_kg": round(random.uniform(0.05, 6.0), 2),
        })
        pid += 1
    return products


def write_products_xml(products):
    root = ET.Element("catalog", attrib={"source": "MerchPIM", "exported_at": "2026-10-01T02:00:00Z"})
    rows = list(products)
    # dirty: 3 products exported twice (an older + a newer record)
    for p in random.sample(products, 3):
        old = dict(p, list_price_usd=round(p["list_price_usd"] - 5, 2))
        rows.append(old)
    random.shuffle(rows)

    for p in rows:
        el = ET.SubElement(root, "product", attrib={"id": p["product_id"], "status": p["status"]})
        ET.SubElement(el, "name").text = p["name"]
        cat = p["category"]
        if chance(0.05):                                   # dirty: casing / whitespace
            cat = random.choice([cat.lower(), cat.upper(), f" {cat} "])
        ET.SubElement(el, "category").text = cat
        ET.SubElement(el, "brand").text = p["brand"]
        sup_id, sup_name, sup_country = p["supplier"]
        ET.SubElement(el, "supplier", attrib={"id": sup_id, "country": sup_country}).text = sup_name

        pricing = ET.SubElement(el, "pricing", attrib={"currency": "USD"})
        ET.SubElement(pricing, "list_price").text = f"{p['list_price_usd']:.2f}"
        if chance(0.03):                                   # dirty: missing cost
            ET.SubElement(pricing, "unit_cost")
        elif chance(0.04):                                 # dirty: cost as "$12.30"
            ET.SubElement(pricing, "unit_cost").text = f"${p['unit_cost_usd']:.2f}"
        else:
            ET.SubElement(pricing, "unit_cost").text = f"{p['unit_cost_usd']:.2f}"

        d = p["launch_date"]
        ET.SubElement(el, "launch_date").text = d.strftime("%d/%m/%Y") if chance(0.06) else d.isoformat()
        ET.SubElement(el, "weight_kg").text = f"{p['weight_kg']}"

        if p["category"] == "Apparel" or chance(0.3):      # optional nested attributes
            attrs = ET.SubElement(el, "attributes")
            ET.SubElement(attrs, "color").text = random.choice(COLORS)
            if p["category"] == "Apparel":
                ET.SubElement(attrs, "size_range").text = f"{random.choice(SIZES[:2])}-{random.choice(SIZES[3:])}"

    ET.indent(root)
    ET.ElementTree(root).write(OUT / "product_catalog.xml", encoding="utf-8", xml_declaration=True)
    return len(rows)

# ---------------------------------------------------------------- finance (Excel)

def build_fx():
    rates, current = [], dict(BASE_FX)
    for d in DAYS:
        if d.weekday() >= 5:                               # realistic: no weekend rates
            continue
        for cur in ["USD", "CAD", "EUR", "GBP"]:
            if cur != "USD":
                current[cur] = round(current[cur] * random.uniform(0.996, 1.004), 4)
            rate = current[cur]
            row = {"rate_date": d, "currency": cur, "rate_to_usd": rate, "source": "ECB/BoC feed"}
            if chance(0.02) and cur != "USD":              # dirty: missing rate
                row["rate_to_usd"] = None
            elif chance(0.02) and cur != "USD":            # dirty: typed as text with comma
                row["rate_to_usd"] = f"{rate:.4f}".replace(".", ",")
            if chance(0.03):                               # dirty: date typed as text
                row["rate_date"] = d.strftime("%m/%d/%Y")
            if chance(0.02):                               # dirty: lowercase code
                row["currency"] = cur.lower()
            rates.append(row)
    return rates, current


def write_finance_xlsx(fx_rows):
    loc_cols = ["location_id", "location_name", "channel", "city", "country", "region",
                "currency", "store_manager", "opening_date", "store_size_sqm",
                "monthly_rent_local", "status"]
    locations = pd.DataFrame(LOCATIONS, columns=loc_cols)
    fx = pd.DataFrame(fx_rows)
    with pd.ExcelWriter(OUT / "finance_reference.xlsx") as xw:
        locations.to_excel(xw, sheet_name="locations", index=False)
        fx.to_excel(xw, sheet_name="fx_rates", index=False)
    return len(locations), len(fx)

# ---------------------------------------------------------------- stores (CSV)

def local_price(usd, currency):
    return charm(usd / BASE_FX[currency]) if currency != "USD" else usd


def write_pos_csv(products):
    active = [p for p in products if p["status"] == "active"]
    stores = [l for l in LOCATIONS if l[2] == "store" and l[11] == "active"]
    cols = ["transaction_id", "line_no", "location_id", "register_id", "cashier_id",
            "transaction_datetime", "product_id", "quantity", "unit_price", "currency",
            "discount_pct", "payment_method", "loyalty_member_id"]
    rows = []
    for d in DAYS:
        for loc in stores:
            loc_id, currency = loc[0], loc[6]
            n_tx = random.randint(5, 9) + (3 if d.weekday() >= 5 else 0)
            for t in range(1, n_tx + 1):
                tx_id = f"{loc_id}-{d:%Y%m%d}-{t:04d}"
                ts = datetime.combine(d, datetime.min.time()) + timedelta(
                    hours=random.randint(9, 20), minutes=random.randint(0, 59), seconds=random.randint(0, 59))
                register, cashier = f"R{random.randint(1, 4)}", f"E{random.randint(100, 140)}"
                payment = random.choice(["card", "card", "card", "cash", "mobile", "gift_card"])
                loyalty = f"L{random.randint(100000, 999999)}" if chance(0.35) else ""
                for line in range(1, random.choice([1, 1, 1, 2, 2, 3]) + 1):
                    p = random.choice(active)
                    qty = random.choice([1, 1, 1, 1, 2, 2, 3])
                    price = local_price(p["list_price_usd"], currency)
                    row = {
                        "transaction_id": tx_id, "line_no": line, "location_id": loc_id,
                        "register_id": register, "cashier_id": cashier,
                        "transaction_datetime": ts.strftime("%Y-%m-%d %H:%M:%S"),
                        "product_id": p["product_id"], "quantity": qty,
                        "unit_price": f"{price:.2f}", "currency": currency,
                        "discount_pct": random.choice([0, 0, 0, 0, 10, 15, 20]),
                        "payment_method": payment, "loyalty_member_id": loyalty,
                    }
                    # Berlin's POS is set to German locale
                    if loc_id == "ST-BER":
                        row["transaction_datetime"] = ts.strftime("%d.%m.%Y %H:%M")
                        row["unit_price"] = row["unit_price"].replace(".", ",")
                    # dirty data
                    if chance(0.02):  row["quantity"] = -row["quantity"]          # returns
                    if chance(0.02):  row["location_id"] = random.choice([loc_id.lower(), f" {loc_id}"])
                    if chance(0.01):  row["product_id"] = f"{p['product_id']} "
                    if chance(0.004): row["product_id"] = random.choice(["P9999", "P0000", "UNKNOWN"])
                    if chance(0.01):  row["payment_method"] = ""
                    if chance(0.01):  row["currency"] = ""
                    if chance(0.005): row["unit_price"] = ""
                    rows.append(row)
                    if chance(0.01):  rows.append(dict(row))                       # POS resend duplicate

    with (OUT / "pos_store_sales_2026Q3.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        w.writerows(rows)
    return len(rows)

# ---------------------------------------------------------------- e-commerce (JSON lines)

FIRST = ["alex", "sam", "maria", "jonas", "li", "fatima", "noah", "emma", "lucas", "aisha", "tom", "sofia", "omar", "mia"]
LAST = ["smith", "muller", "garcia", "chen", "brown", "dubois", "rossi", "khan", "novak", "silva", "lee", "martin"]

STOREFRONTS = {
    "WEB-NA": [("US", "USD", 0.8), ("CA", "CAD", 0.2)],
    "WEB-EU": [("DE", "EUR", 0.35), ("FR", "EUR", 0.25), ("NL", "EUR", 0.15), ("GB", "GBP", 0.25)],
}


def write_ecommerce_json(products, n_orders=2000):
    active = [p for p in products if p["status"] == "active"]
    customers = {}
    events = []
    for i in range(1, n_orders + 1):
        sf = random.choices(["WEB-NA", "WEB-EU"], weights=[0.55, 0.45])[0]
        country, currency, _ = random.choices(STOREFRONTS[sf], weights=[c[2] for c in STOREFRONTS[sf]])[0]
        d = random.choice(DAYS)
        ts = datetime.combine(d, datetime.min.time(), tzinfo=timezone.utc) + timedelta(seconds=random.randint(0, 86399))

        cust_id = f"C{random.randint(10000, 13500)}"
        if cust_id not in customers:
            customers[cust_id] = f"{random.choice(FIRST)}.{random.choice(LAST)}{random.randint(1, 99)}@example.com"
        is_test = chance(0.005)

        items = []
        for p in random.sample(active, k=random.choice([1, 1, 2, 2, 3, 4])):
            qty = random.choice([1, 1, 1, 2, 3])
            item = {"product_id": p["product_id"],
                    "qty": str(qty) if chance(0.03) else qty,            # dirty: number as string
                    "unit_price": local_price(p["list_price_usd"], currency),
                    "line_discount": random.choice([0, 0, 0, 0.1])}
            items.append(item)

        status = random.choices(["completed", "refunded", "cancelled"], weights=[0.88, 0.07, 0.05])[0]
        order = {
            "event_id": f"evt_{random.getrandbits(48):012x}",
            "event_type": "order_placed",
            "order_id": f"WO-2026-{i:06d}",
            "order_ts": ts.isoformat().replace("+00:00", "Z"),
            "storefront": sf,
            "customer": {
                "customer_id": "TEST-0001" if is_test else cust_id,
                "email": "qa@meridiangoods.test" if is_test else (None if chance(0.03) else customers[cust_id]),
                "country": country,
                "is_new_customer": chance(0.3),
            },
            "currency": None if chance(0.02) else currency,              # dirty: missing currency
            "items": items,
            "shipping": {"method": random.choice(["standard", "standard", "express"]),
                         "fee": random.choice([0.0, 0.0, 4.99, 9.99])},
            "payment": {"method": random.choice(["card", "paypal", "apple_pay", "klarna"]), "status": "captured"},
            "promo_code": random.choice([None, None, None, None, "SUMMER10", "WELCOME15", "BACK2SCHOOL"]),
            "device": random.choice(["mobile", "mobile", "desktop", "tablet"]),
            "status": "completed" if status == "refunded" else status,
        }
        if chance(0.03):                                                 # dirty: epoch millis timestamp
            order["order_ts"] = int(ts.timestamp() * 1000)
        events.append(order)

        if status == "refunded":                                         # later update event, same order_id
            upd = json.loads(json.dumps(order))
            upd["event_id"] = f"evt_{random.getrandbits(48):012x}"
            upd["event_type"] = "order_updated"
            upd["status"] = "refunded"
            upd["updated_ts"] = (ts + timedelta(days=random.randint(2, 14))).isoformat().replace("+00:00", "Z")
            events.append(upd)
        if chance(0.02):                                                 # dirty: exact duplicate event
            events.append(json.loads(json.dumps(order)))

    events.sort(key=lambda e: e.get("updated_ts") or (e["order_ts"] if isinstance(e["order_ts"], str)
                                                         else datetime.fromtimestamp(e["order_ts"] / 1000, timezone.utc).isoformat()))
    with (OUT / "ecommerce_orders_2026Q3.json").open("w", encoding="utf-8") as f:
        for e in events:
            f.write(json.dumps(e) + "\n")
    line_items = sum(len(e["items"]) for e in events)
    return len(events), line_items

# ---------------------------------------------------------------- main

if __name__ == "__main__":
    OUT.mkdir(parents=True, exist_ok=True)
    products = build_products()
    n_prod = write_products_xml(products)
    fx_rows, _ = build_fx()
    n_loc, n_fx = write_finance_xlsx(fx_rows)
    n_pos = write_pos_csv(products)
    n_evt, n_items = write_ecommerce_json(products)
    print(f"product_catalog.xml          {n_prod} products")
    print(f"finance_reference.xlsx       {n_loc} locations, {n_fx} fx rows")
    print(f"pos_store_sales_2026Q3.csv   {n_pos} sale lines")
    print(f"ecommerce_orders_2026Q3.json {n_evt} order events ({n_items} line items)")
