# Reproduce the Pipeline – Step by Step

Follow these steps in order. Each step says **what** to do and **why**.

---

## 1. Create the storage in Databricks (Catalog Explorer)

Databricks organizes data in three levels:

```
Catalog  etl_meridian_project      ← the whole project
└─ Schema  etl_meridianschema       ← one area of the project
   └─ Volume  etl_meridianvolume    ← where files (not tables) live
```

1. **Catalog** → **Create catalog** → `etl_meridian_project`. If you don't have permission, use the existing `workspace` catalog.
2. Inside it, **Create schema** → `etl_meridianschema`.
3. Inside the schema, **Create volume** → `etl_meridianvolume` (managed).
4. Open the volume, **create a directory** named `raw`, and **upload the 4 files** from `data/raw/` into it.

The notebooks create the other folders (`bronze/`, `silver/`, `processed/`, `logs/`) automatically.

**If you uploaded the files to the volume root by mistake,** run this once in a notebook cell to move them into `raw/`:
```python
import glob, shutil
VOLUME_DIR = "/Volumes/etl_meridian_project/etl_meridianschema/etl_meridianvolume"
for file in glob.glob(f"{VOLUME_DIR}/*.*"):      # *.* = files only (skips folders)
    shutil.move(file, f"{VOLUME_DIR}/raw")       # move each file into raw/
```

## 2. Import the notebooks (Workspace)

Code lives in the **Workspace**, and data lives in the **Volume**. Keep them separate.

1. **Workspace** → **Users → your email** → **Create → Folder**, and name it `meridian_etl`.
2. Inside the folder, **Import** → select the 4 files from `notebooks/`. They're in Databricks source format, so each becomes a notebook with its cells.
3. Alternatively, connect the GitHub repo with **Create → Git folder** and paste the repo URL.

## 3. Configure the path

Each notebook starts with the same block. If your catalog, schema or volume names differ, edit **only** this line in **all four** notebooks:

```python
VOLUME_DIR = "/Volumes/etl_meridian_project/etl_meridianschema/etl_meridianvolume"
```

> `/Volumes` must start with a **capital V**. Copy the path from Catalog Explorer to avoid typos.

## 4. Dependencies

Databricks already includes `pandas`, `numpy` and `pyarrow`. Excel files need `openpyxl`. If `01_extract` fails with `ImportError: openpyxl`, add this as its **first cell**:

```python
%pip install openpyxl     # Excel reader used by pd.read_excel
```

For local work, such as regenerating the data, use `requirements.txt`:

```bash
pip install -r requirements.txt                  # pandas, numpy, openpyxl, pyarrow
```

## 5. Run the pipeline

**Manually:** open each notebook and click **Run all**, in this order:

| Order | Notebook | Reads | Writes |
|---|---|---|---|
| 1 | `01_extract` | `raw/` | `bronze/*.parquet` |
| 2 | `02_transform` | `bronze/` | `silver/*.parquet` |
| 3 | `03_load` | `silver/` | `processed/sales_consolidated.csv` |
| 4 | `04_analysis` | `processed/` | summary tables (display only) |

The order matters because each notebook reads the previous one's output from the Volume. Notebooks **don't share memory**.

## 6. Orchestrate and schedule with Databricks Jobs

1. Open **Jobs & Pipelines** in the sidebar (older workspaces call it **Workflows**) → **Create job**, and name it `meridian_sales_etl`.
2. Add 4 tasks, each with **Type: Notebook** and **Source: Workspace**:

| Task name | Notebook | Depends on |
|---|---|---|
| `extract` | `01_extract` | none |
| `transform` | `02_transform` | `extract` |
| `load` | `03_load` | `transform` |
| `analysis` | `04_analysis` | `load` |

3. **Schedules & Triggers** → **Add trigger** → **Scheduled**, e.g. daily at 02:00.
4. Click **Run now** once to test it. If a task fails, the tasks after it are skipped, and the failed task's output shows the error.

## 7. Validate the run

Run these in any notebook cell:

```python
import os, pandas as pd
VOLUME_DIR = "/Volumes/etl_meridian_project/etl_meridianschema/etl_meridianvolume"

# 1. Every layer has its files
for layer in ["raw", "bronze", "silver", "processed", "logs"]:
    print(layer, os.listdir(f"{VOLUME_DIR}/{layer}"))

# 2. The log shows the full run from start to end
print(open(f"{VOLUME_DIR}/logs/etl_log.txt").read()[-1500:])   # last ~1500 characters

# 3. The Gold file has the expected shape and no duplicate sale IDs
gold = pd.read_csv(f"{VOLUME_DIR}/processed/sales_consolidated.csv")
print(gold.shape)                          # expected (9201, 17)
print(gold["sale_id"].duplicated().sum())  # expected 0
```

**Expected row counts on the sample data:**

| Table | Bronze | Silver |
|---|---|---|
| store_sales | 4,945 | 4,844 |
| web_orders | 4,796 | 4,357 |
| products | 203 | 200 |
| locations | 7 | 7 |
| fx_rates | 264 | 368 (weekends filled) |
| **Gold** | | **9,201 × 17** |

## 8. Regenerate the sample data (optional)

```bash
python scripts/generate_raw_data.py      # writes 4 files to ./data/raw/ (seeded: same output each run)
```

## 9. Publish to GitHub

**From your computer:**
```bash
cd meridian-multiformat-etl               # go into the project folder
git init                                  # start a new git repository
git add .                                 # stage all files
git commit -m "Multi-format sales consolidation ETL on Databricks"   # first snapshot
git branch -M main                        # name the main branch "main"
git remote add origin https://github.com/murltre/meridian-multiformat-etl.git   # link to GitHub
git push -u origin main                   # upload and set the default remote
```
Create the empty repo on github.com first, without a README, or run `gh repo create murltre/meridian-multiformat-etl --public --source=. --push` to create and push in one step.

**From Databricks:** use the Git folder from step 2 → **Git…** → commit and push.
